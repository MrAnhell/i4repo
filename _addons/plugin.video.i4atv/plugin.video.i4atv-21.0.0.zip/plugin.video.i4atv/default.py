# -*- coding: utf-8 -*-
import sys
import os
import json
import urllib
import urllib2
import urlparse
import xbmcaddon
import xbmcgui
import xbmcplugin
import load_channels
import hashlib
import re
import time
import xbmc
import net
import server
import config
import shutil
import unicodedata
import xbmc
import base64

from t0mm0.common.addon import Addon
from metahandler import metahandlers

addon_id = 'plugin.video.i4atv'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
Decode = base64.decodestring
directoryr = xbmc.translatePath('special://home/userdata/addon_data/script.renegadestv/')
destinaddonsr = xbmc.translatePath('special://home/userdata/addon_data/script.renegadestv/addons2.ini')
destinsetsr = xbmc.translatePath('special://home/userdata/addon_data/script.renegadestv/settings.xml')
reload = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.i4atv/settings.xml')
destmw1dir = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.i4atv/')
destinf1 = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.i4atv/http_mw1_iptv66_tv-genres')
destinf2 = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.i4atv/http_mw1_iptv66_tv')
metaset = selfAddon.getSetting('enable_meta')

user = selfAddon.getSetting('username')
passw = selfAddon.getSetting('password')

plugin_handle = int(sys.argv[1])

mysettings = xbmcaddon.Addon(id = 'plugin.video.i4atv')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
online_m3u = mysettings.getSetting('online_m3u')
local_m3u = mysettings.getSetting('local_m3u')
online_xml = ('http://shanghai.watchkodi.com/Sections/Sports/Live%20games%20+%20Events/Live%20Football.xml')
local_xml = mysettings.getSetting('local_xml')
xml_regex = '<title>(.*?)</title>\s*<link>(.*?)</link>\s*<thumbnail>(.*?)</thumbnail>'
m3u_thumb_regex = 'tvg-logo=[\'"](.*?)[\'"]'
m3u_regex = '#(.+?),(.+)\s*(.+)\s*'
u_tube = 'http://www.youtube.com'

addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
addondir    = xbmc.translatePath( addon.getAddonInfo('profile') ) 

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
go = True;

xbmcplugin.setContent(addon_handle, 'movies')

net = net.Net()
dialog = xbmcgui.Dialog()


def Main():
	addDir('[COLOR yellow]LOGIN[/COLOR]','0',3008,icon, fanart)
	addDir('[COLOR yellow]LOGOUT[/COLOR]','0',3009,icon, fanart)
	addDir('[COLOR magenta][I]###--Maintenance Tools Below--###[/I][/COLOR]','',0,icon, fanart)
	addDir('[COLOR blue]CLEAR CACHE[/COLOR]','0',1000,icon, fanart)
	addDir('[COLOR blue]DELETE PACKAGES[/COLOR]','0',1001,icon, fanart)
	addDir('[COLOR blue]DELETE I4ATV USERDATA[/COLOR]','0',1003,icon, fanart)
	addDir('[COLOR blue]REFRESH I4ATV CHANNEL LIST[/COLOR]','0',1004,icon, fanart)
	addDir('[COLOR magenta][I]###--Live TV Below--###[/I][/COLOR]','',0,icon, fanart)
	addDir('[COLOR red]I4ATV EXTRA[/COLOR] [COLOR yellow][I]>IPTV<[/I][/COLOR] [COLOR green][I]>FREE<[/I][/COLOR]','0',1,icon, fanart)
	
	username = selfAddon.getSetting('username')
	password = selfAddon.getSetting('password')
	
	if user == '' or passw == '':
		dialog.ok("Error", "Please login to i4atv first")
		
	else:
		dir = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.i4atv/')
		url = 'http://hdtrger.x10host.com/user/http_mw1_iptv66_tv'
		url2 = 'http://hdtrger.x10host.com/user/http_mw1_iptv66_tv-genres'
		print("calling %s with %s:%s\n" % (url, username, password))
		print("calling %s with %s:%s\n" % (url2, username, password))
		
		passman = urllib2.HTTPPasswordMgrWithDefaultRealm()
		passman.add_password(None, url, username, password)
		urllib2.install_opener(urllib2.build_opener(urllib2.HTTPBasicAuthHandler(passman)))
		
		req = urllib2.Request(url)
		f = urllib2.urlopen(req)
		data = f.read()
		with open(dir + "http_mw1_iptv66_tv", "wb") as code:
			code.write(data)

		req = urllib2.Request(url2)
		f = urllib2.urlopen(req)
		data2 = f.read()
		with open(dir + "http_mw1_iptv66_tv-genres", "wb") as code:
			code.write(data2)

	xbmc.executebuiltin('Container.SetViewMode(50)')

	
def Login():
	if not os.path.exists(destmw1dir):
		try: 
			os.makedirs(destmw1dir)
		except OSError:
			if not os.path.isdir(destmw1dir):
				raise

	if user == '' or passw == '':
		ret = dialog.yesno('I4ATV EXTRA', 'Please enter your username and password','','','Cancel','Login')
		if ret == 1:
			keyb = xbmc.Keyboard('', 'Enter Username')
			keyb.doModal()
			if (keyb.isConfirmed()):
				search = keyb.getText()
				username=search
				keyb = xbmc.Keyboard('', 'Enter Password:')
				keyb.doModal()
				if (keyb.isConfirmed()):
					search = keyb.getText()
					password=search
					selfAddon.setSetting('username',username)
					selfAddon.setSetting('password',password)
					dialog.ok(addon_id, 'Username and Password are now set. The addon is moitored and if you share this information to steal I4ATV it will result in service termination so keep it secret and safe... Thank You.')
					username = selfAddon.getSetting('username')
					password = selfAddon.getSetting('password')
					dir = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.i4atv/')
					url = 'http://hdtrger.x10host.com/user/http_mw1_iptv66_tv'
					url2 = 'http://hdtrger.x10host.com/user/http_mw1_iptv66_tv-genres'
					print("calling %s with %s:%s\n" % (url, username, password))
					print("calling %s with %s:%s\n" % (url2, username, password))

					passman = urllib2.HTTPPasswordMgrWithDefaultRealm()
					passman.add_password(None, url, username, password)
					passman.add_password(None, url2, username, password)
					urllib2.install_opener(urllib2.build_opener(urllib2.HTTPBasicAuthHandler(passman)))

					req = urllib2.Request(url)
					f = urllib2.urlopen(req)
					data = f.read()
					with open(dir + "http_mw1_iptv66_tv", "wb") as code:
						code.write(data)
	
					req = urllib2.Request(url2)
					f = urllib2.urlopen(req)
					data2 = f.read()
					with open(dir + "http_mw1_iptv66_tv-genres", "wb") as code:
						code.write(data2)		
					quit()
				else:quit()
		
def Logout():
	try:
		os.remove(reload)
		os.remove(destinf1)
		os.remove(destinf2)
		
	except OSError:
		pass
	addDir('[COLOR yellow]*** All Done Now Press Back ***[/COLOR]','0',0,icon,'',fanart)

def RELOADER():
	username = selfAddon.getSetting('username')
	password = selfAddon.getSetting('password')
	
	if user == '' or passw == '':
		dialog.ok("Error", "Please login to i4atv first")
	else:
		dir = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.i4atv/')
		url = 'http://hdtrger.x10host.com/user/http_mw1_iptv66_tv'
		url2 = 'http://hdtrger.x10host.com/user/http_mw1_iptv66_tv-genres'
		print("calling %s with %s:%s\n" % (url, username, password))
		print("calling %s with %s:%s\n" % (url2, username, password))
		
		passman = urllib2.HTTPPasswordMgrWithDefaultRealm()
		passman.add_password(None, url, username, password)
		urllib2.install_opener(urllib2.build_opener(urllib2.HTTPBasicAuthHandler(passman)))
		
		req = urllib2.Request(url)
		f = urllib2.urlopen(req)
		data = f.read()
		with open(dir + "http_mw1_iptv66_tv", "wb") as code:
			code.write(data)

		req = urllib2.Request(url2)
		f = urllib2.urlopen(req)
		data2 = f.read()
		with open(dir + "http_mw1_iptv66_tv-genres", "wb") as code:
			code.write(data2)
		addDir('[COLOR yellow]*** All Done Now Press Back ***[/COLOR]','0',0,icon,'',fanart)
	xbmc.executebuiltin('Container.SetViewMode(50)')
	
def REMOVEUSER():
	if os.path.exists(destmw1dir):
		try: 
			shutil.rmtree(destmw1dir)
		except:
			dialog.ok(addonname, 'Userdata Folder Not Presnt')
		addDir('[COLOR yellow]*** All Done Now Press Back ***[/COLOR]','0',0,icon,'',fanart)

def DELETECACHE(url):
    print '###DELETING STANDARD CACHE###'
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete KODI Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    
	addDir('[COLOR yellow]*** All Done Now Press Back ***[/COLOR]','0',0,icon,'',fanart)
	xbmc.executebuiltin('Container.SetViewMode(50)')
	
def DELETEPACKAGES(url):
    print '###DELETING PACKAGES###'
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
            
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                            
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                    addDir('[COLOR yellow]*** All Done Now Press Back ***[/COLOR]','0',0,icon,'',fanart)
                else:
                        pass
            else:
				addDir('[COLOR yellow]*** No Packages To Delete ***[/COLOR]','0',0,icon,'',fanart)
				addDir('[COLOR yellow]*** All Done Now Press Back ***[/COLOR]','0',0,icon,'',fanart)
    except: 
		addDir('[COLOR yellow]*** There Was An Error ***[/COLOR]','0',0,icon,'',fanart)
		addDir('[COLOR yellow]*** All Done Now Press Back ***[/COLOR]','0',0,icon,'',fanart)
    return
	
def RESOLVE(url,name): 
    play=xbmc.Player(GetPlayerCore())
    import urlresolver
    try: play.play(url)
    except: pass
    from urlresolver import common
    dp = xbmcgui.DialogProgress()
    dp.create('[COLORlime]Architects@Work[/COLOR]','Opening %s Now'%(name))
    if dp.iscanceled(): 
        print "[COLORred]STREAM CANCELLED[/COLOR]" # need to get this part working    
        dp.update(100)
        dp.close()
        dialog = xbmcgui.Dialog()
        if dialog.yesno("[B]CANCELLED[/B]", '[B]Was There A Problem[/B]','', "",'Yes','No'):
            dialog.ok("Message Send", "Your Message Has Been Sent")
        else:
	         return
    else:
        try: play.play(url)
        except: pass
        try: ADDON.resolve_url(url) 
        except: pass 
  
def GetChannels():
	if user == '' or passw == '':
		addDir('[COLOR yellow]*** Press Back An Login First ***[/COLOR]','0',0,icon,'',fanart)
		return;
	else:
		html=OPEN_URL('http://uktvnow.desistreams.tv/DesiStreams/index202.php?tag=get_all_channel&username=inside4ndroid')
		match = re.compile('"id":".+?","name":"(.+?)","img":"(.+?)","stream_url3":"(.+?)","cat_id":".+?","stream_url2":"(.+?)","stream_url":"(.+?)"}',re.DOTALL).findall(html)
		for name,img,url,url2,url3 in match:
			addDir1('[COLORwhite]'+name+'[/COLOR] [COLORgreen][I]L1[/I][/COLOR]',(url).replace('\\',''),1002,'http://uktvnow.desistreams.tv/' + (img).replace('\\',''))
			addDir1('[COLORwhite]'+name+'[/COLOR] [COLORgreen][I]L2[/I][/COLOR]',(url2).replace('\\',''),1002,'http://uktvnow.desistreams.tv/' + (img).replace('\\',''))
			addDir1('[COLORwhite]'+name+'[/COLOR] [COLORgreen][I]L3[/I][/COLOR]',(url3).replace('\\',''),1002,'http://uktvnow.desistreams.tv/' + (img).replace('\\',''))
		
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

def addLink(name,url,mode,iconimage,fanart,description=''):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
		liz.setProperty('fanart_image', fanart)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok

def addDir(name,url,mode,iconimage,fanart,description=''):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
		liz.setProperty('fanart_image', fanart)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok
		
def addDir1(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def GetPlayerCore(): 
    try: 
        PlayerMethod=getSet("core-player") 
        if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER 
        elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER 
        elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER 
        else: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    except: PlayerMeth=xbmc.PLAYER_CORE_AUTO 
    return PlayerMeth 
    return True 
	
def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				e4=sys.argv[2]
				cleanedparams=e4.replace('?','')
				if (e4[len(e4)-1]=='/'):
						e4=e4[0:len(e4)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]	
		return param
		   
e4=get_params()
url=None
name=None
mode=None
iconimage=None
description=None

try:url=urllib.unquote_plus(e4["url"])
except:pass
try:name=urllib.unquote_plus(e4["name"])
except:pass
try:mode=int(e4["mode"])
except:pass
try:iconimage=urllib.unquote_plus(e4["iconimage"])
except:pass

if mode==None or url==None or len(url)<1:Main()
elif mode==1:GetChannels()
elif mode==1000:DELETECACHE(url)
elif mode==1001:DELETEPACKAGES(url)
elif mode==1002:RESOLVE(url,name)
elif mode==1003:REMOVEUSER()
elif mode==1004:RELOADER()
elif mode==3008:Login()
elif mode==3009:Logout()

def removeAccents(s):
	return ''.join((c for c in unicodedata.normalize('NFD', s.decode('utf-8')) if unicodedata.category(c) != 'Mn'))
					
def read_file(file):
    try:
        f = open(file, 'r')
        content = f.read()
        f.close()
        return content
    except:
        pass

def make_request(url):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0')
		response = urllib2.urlopen(req)	  
		link = response.read()
		response.close()  
		return link
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code	
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason

def addPortal(portal):

	if portal['url'] == '':
		return;

	url = build_url({
		'mode': 'genres', 
		'portal' : json.dumps(portal)
		});

	cmd = 'XBMC.RunPlugin(' + base_url + '?mode=cache&stalker_url=' + portal['url'] + ')';	
	li = xbmcgui.ListItem(portal['name'], iconImage='special://home/addons/pulgin.video.i4atv/icon.png')
	

	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
	
	
	
def build_url(query):
	return base_url + '?' + urllib.urlencode(query)


def homeLevel():
	global portal_1, portal_2, portal_3, go;
	
	#todo - check none portal

	if go:
		addPortal(portal_1);
		
	
		xbmcplugin.endOfDirectory(addon_handle);
		

def genreLevel():
	
	try:
		data = load_channels.getGenres(portal['mac'], portal['url'], portal['serial'], addondir);
		
	except Exception as e:
	
		xbmcgui.Dialog().notification(addonname, 'Press Back And Login First', xbmcgui.NOTIFICATION_ERROR );
		return;

	data = data['genres'];
		
	url = build_url({
		'mode': 'vod', 
		'portal' : json.dumps(portal)
	});
			
	li = xbmcgui.ListItem('SELECT A TV CATEGORY FROM BELOW', iconImage='special://home/addons/plugin.video.i4atv/icon.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False);
	
	
	for id, i in data.iteritems():

		title 	= i["title"];
		
		url = build_url({
			'mode': 'channels', 
			'genre_id': id, 
			'genre_name': title.title(), 
			'portal' : json.dumps(portal)
			});
			
		

		
		if id == '68':
			iconImage = 'special://home/addons/plugin.video.i4atv/icon.jpg';
		else:
			iconImage = 'special://home/addons/plugin.video.i4atv/icon.png';
			
			
		li = xbmcgui.ListItem(title.title(), iconImage=iconImage)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
		
			
			
	
		

	xbmcplugin.endOfDirectory(addon_handle);
	
	
	

def vodLevel():
	
	try:
		data = load_channels.getVoD(portal['mac'], portal['url'], portal['serial'], addondir);
		
	except Exception as e:
		xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
		return;
	
	
	data = data['vod'];
	
		
	for i in data:
		name 	= i["name"];
		cmd 	= i["cmd"];
		logo 	= i["logo"];
		
		
		if logo != '':
			logo_url = portal['url'] + logo;
		else:
			logo_url = 'special://home/addons/plugin.video.i4atv/icon.png';
				
				
		url = build_url({
				'mode': 'play', 
				'cmd': cmd, 
				'tmp' : '0', 
				'title' : name.encode("utf-8"),
				'genre_name' : 'VoD',
				'logo_url' : logo_url, 
				'portal' : json.dumps(portal)
				});
			

		li = xbmcgui.ListItem(name, iconImage=logo_url, thumbnailImage=logo_url)
		li.setInfo(type='Video', infoLabels={ "Title": name })

		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
	
	xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
	xbmcplugin.endOfDirectory(addon_handle);

def channelLevel():
	stop=False;
		
	try:
		data = load_channels.getAllChannels(portal['mac'], portal['url'], portal['serial'], addondir);
		
	except Exception as e:
		xbmcgui.Dialog().notification(Wrong, str(e), xbmcgui.NOTIFICATION_ERROR );
		return;
	
	
	data = data['channels'];
	genre_name 	= args.get('genre_name', None);
	
	genre_id_main = args.get('genre_id', None);
	genre_id_main = genre_id_main[0];
	
	if genre_id_main == '68' and portal['parental'] == 'true':
		result = xbmcgui.Dialog().input('Parental', hashlib.md5(portal['password'].encode('utf-8')).hexdigest(), type=xbmcgui.INPUT_PASSWORD, option=xbmcgui.PASSWORD_VERIFY);
		if result == '':
			stop = True;

	
	if stop == False:
		for i in data.values():
			
			name 		= i["name"];
			cmd 		= i["cmd"];
			tmp 		= i["tmp"];
			number 		= i["number"];
			genre_id 	= i["genre_id"];
			logo 		= i["logo"];
		
			if genre_id_main == '*' and genre_id == '10' and portal['parental'] == 'true':
				continue;
		
		
			if genre_id_main == genre_id or genre_id_main == '*':
		
				if logo != '':
					logo_url = portal['url'] + '/stalker_portal/misc/logos/320/' + logo;
				else:
					logo_url = 'special://home/addons/plugin.video.i4atv/icon.png';
				
				
				url = build_url({
					'mode': 'play', 
					'cmd': cmd, 
					'tmp' : tmp, 
					'title' : name.encode("utf-8"),
					'genre_name' : genre_name,
					'logo_url' : logo_url,  
					'portal' : json.dumps(portal)
					});
			

				li = xbmcgui.ListItem(name, iconImage=logo_url, thumbnailImage=logo_url);
				li.setInfo(type='Video', infoLabels={ 
					'title': name,
					'count' : number
					});

				xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li);
		
		
		xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
		xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PROGRAM_COUNT);
		
		
		xbmcplugin.endOfDirectory(addon_handle);

def playLevel():
	
	dp = xbmcgui.DialogProgressBG();
	dp.create('Channel', 'Loading ...');
	
	title 	= args['title'][0];
	cmd 	= args['cmd'][0];
	tmp 	= args['tmp'][0];
	genre_name 	= args['genre_name'][0];
	logo_url 	= args['logo_url'][0];
	
	try:
		if genre_name != 'VoD':
			url = load_channels.retriveUrl(portal['mac'], portal['url'], portal['serial'], cmd, tmp);
		else:
			url = load_channels.retriveVoD(portal['mac'], portal['url'], portal['serial'], cmd);

	
	except Exception as e:
		dp.close();
		xbmcgui.Dialog().notification(addonname, 'Streaming Error Please Try Again', xbmcgui.NOTIFICATION_ERROR );
		return;

	
	dp.update(80);
	
	title = title.decode("utf-8");
	
	title += ' (' + portal['name'] + ')';
	

	li = xbmcgui.ListItem(title, iconImage='special://home/addons/plugin.video.i4atv/icon.png', thumbnailImage=logo_url);
	li.setInfo('video', {'Title': title, 'Genre': genre_name});
	xbmc.Player().play(item=url, listitem=li);
	
	dp.update(100);
	
	dp.close();


mode = args.get('mode', None);
portal =  args.get('portal', None)


if portal is None:
	portal_1 = config.portalConfig('1');
	portal_2 = config.portalConfig('2');
	portal_3 = config.portalConfig('3');	

else:
	portal = json.loads(portal[0]);



	portal_2 = config.portalConfig('2');
	portal_3 = config.portalConfig('3');	

	if not ( portal['name'] == portal_2['name'] or portal['name'] == portal_3['name'] ) :
		portal = config.portalConfig('1');

	

if mode is None:
	homeLevel();

elif mode[0] == 'cache':	
	stalker_url = args.get('stalker_url', None);
	stalker_url = stalker_url[0];	
	load_channels.clearCache(stalker_url, addondir);

elif mode[0] == 'genres':
	genreLevel();
		
elif mode[0] == 'vod':
	vodLevel();

elif mode[0] == 'channels':
	channelLevel();
	
elif mode[0] == 'play':
	playLevel();
	
elif mode[0] == 'server':
	port = addon.getSetting('server_port');
	
	action =  args.get('action', None);
	action = action[0];
	
	dp = xbmcgui.DialogProgressBG();
	dp.create('I4ATV', 'Just A Second ...');
	
	if action == 'start':
	
		if server.serverOnline():
			xbmcgui.Dialog().notification(addonname, 'Server already started.\nPort: ' + str(port), xbmcgui.NOTIFICATION_INFO );
		else:
			server.startServer();
			time.sleep(5);
			if server.serverOnline():
				xbmcgui.Dialog().notification(addonname, 'Server started.\nPort: ' + str(port), xbmcgui.NOTIFICATION_INFO );
			else:
				xbmcgui.Dialog().notification(addonname, 'Server not started. Wait one moment and try again. ', xbmcgui.NOTIFICATION_ERROR );
				
	else:
		if server.serverOnline():
			server.stopServer();
			time.sleep(5);
			xbmcgui.Dialog().notification(addonname, 'Server stopped.', xbmcgui.NOTIFICATION_INFO );
		else:
			xbmcgui.Dialog().notification(addonname, 'Server is already stopped.', xbmcgui.NOTIFICATION_INFO );
			
	dp.close();
	
xbmcplugin.endOfDirectory(int(sys.argv[1]))
xbmcplugin.endOfDirectory(plugin_handle)
