import sys
import os
import json
import urllib
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import load_channels
import hashlib
import re
import random
import base64
import urllib2
from urllib2 import URLError
import server

addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
addondir    = xbmc.translatePath( addon.getAddonInfo('profile') ) 
current     = os.getcwd()
folder = 'http://hdtrger.x10host.com/user/'
urlset  = ['test1','test2','test3','test4','test5']

eternal		= (random.choice(urlset))
addon_id = 'plugin.video.i4atv'
selfAddon = xbmcaddon.Addon(id=addon_id)

username = selfAddon.getSetting('username')
password = selfAddon.getSetting('password')
path = (folder + eternal)

def portalConfig(number):

		portal = {};
	
		portal['parental'] = addon.getSetting("parental");
		portal['password'] = addon.getSetting("password");
	
		portal['name'] = addon.getSetting("portal_name_" + number);
		portal['url'] = addon.getSetting("portal_url_" + number);
		portal['mac'] = configMac(number);
		portal['serial'] = configSerialNumber(number);
		
		return portal;


def configMac(number):
	global go;
	import urllib2
	import sys
	
	if not username:
		data = '01:1A:78:00:00:00'
	else:
		print("calling %s with %s:%s\n" % (path, username, password))
		passman = urllib2.HTTPPasswordMgrWithDefaultRealm()
		passman.add_password(None, path, username, password)
		urllib2.install_opener(urllib2.build_opener(urllib2.HTTPBasicAuthHandler(passman)))

		urllib2.urlopen(path)
		req = urllib2.Request(path)
		f = urllib2.urlopen(req)
		data = f.read()
		print data

	custom_mac = ('Y3VzdG9tX21hY18x'.decode('base64'));
	portal_mac = ('cG9ydGFsX21hY18x'.decode('base64'));
	
	if custom_mac != 'true':
		portal_mac = (data);
		
	elif not (custom_mac == 'true' and re.match("WzAtOWEtZl17Mn0oWy06XSlbMC05YS1mXXsyfShcXDFbMC05YS1mXXsyfSl7NH0k".decode('base64'), portal_mac.lower()) != None):
		xbmcgui.Dialog().notification(addonname, 'Mac ' + number + ' is Invalid.', xbmcgui.NOTIFICATION_ERROR );
		portal_mac = '';
		go=False;
		
	return portal_mac;
	
	
def configSerialNumber(number):
	global go;
	
	send_serial = addon.getSetting('send_serial_' + number);
	custom_serial = addon.getSetting('custom_serial_' + number);
	serial_number = addon.getSetting('serial_number_' + number);
	device_id = addon.getSetting('device_id_' + number);
	device_id2 = addon.getSetting('device_id2_' + number);
	signature = addon.getSetting('signature_' + number);

	
	if send_serial != 'true':
		return None;
	
	elif send_serial == 'true' and custom_serial == 'false':
		return {'custom' : False};
		
	elif send_serial == 'true' and custom_serial == 'true':
	
		if serial_number == '' or device_id == '' or device_id2 == '' or signature == '':
			xbmcgui.Dialog().notification(addonname, 'Serial information is invalid.', xbmcgui.NOTIFICATION_ERROR );
			go=False;
			return None;
	
		return {'custom' : True, 'sn' : serial_number, 'device_id' : device_id, 'device_id2' : device_id2, 'signature' : signature};
		
	return None;